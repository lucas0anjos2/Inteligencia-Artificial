import random
import math

__name__ = 'TDA'

MOVE_UP = 1
MOVE_DOWN = 2
MOVE_RIGHT = 3
MOVE_LEFT = 4
destino = []
visitados = []
caminhoFeito = []
caminhoInverso = []
posAnterior = []
z = -1
k = -1
y = -1
j = -1
h = -1
n = -1
varAux = 0
turno = 0
#funcao que escolhe um destino para ir
def escolheDestino(resources):
	destino = []
	destino = resources[random.randint(0,len(resources))]
	return destino

#está funcao valida meus possiveis movimentos, em relacao a posicao do meu agente
def validaMovimento(visitados, coordenada, map):
	flag1 = False
	flag2 = False
	#verificando se o meu proximo movimento nao esta fora do escopo da minha matriz
	if coordenada[0]==-1 and coordenada[1] > -1:
		flag1 = True
	else:
		if coordenada[0] > -1 and coordenada[1] == -1:
			flag1 = True

	#verifico se uma das posicoes da coordenada nao possui tam igual ex a 30, pois como em python o indice comeca em 0, linha e coluna vai de 0 - 29
	if coordenada[0]==len(map)-1 or coordenada[1]==len(map)-1:
		flag1 = True

	#verificando se o meu proximo movimento nao esta na lista de visitados
	for i in range(0, len(visitados)):
		if coordenada == visitados[i]:
			flag2 = True

	a = False
	b = True
	#se essa condicao der verdadeiro quer dizer que é viavel eu ir para aquela posicao, onde eu n estou acessando posicao fora do escopo	
	if flag1 == True or flag2 == True:
		return a
	else:
		return b

def mostrarFGH(F, G, H):
	print("Valor G: ", G)
	print("Valor H: ", H)
	print("Funcao F: ", F)

def calcularGeH(map, coordenada, player_pos, destino):
	G = 0
	H = 0
	F = 0
	G = -(abs(map[tuple(coordenada)] - map[tuple(player_pos)])) - 1
	H = int(math.sqrt((destino[1] - coordenada[1])**2 + (destino[0] - coordenada[0])**2))
	F = H + G
	mostrarFGH(F,G,H)
	return F

def calculaLucro(coordenada, resources):
	lucro = 0
	for i in range(0, len(resources)):
		if resources[i][0] == coordenada[0] and resources[i][1] == coordenada[1]:
			if resources[i][2] == 'g':
				lucro = 50
			else:
				if resources[i][2] == 'w':
					lucro = 30
	return lucro
		
def calcularCustoF(map, player_pos, destino, visitados, resources):
	F = None
	possiveisMovimentos = []
	i = 0
	lucro = 0
	coordenadaEsqPlayerPos = []
	coordenadaCimaPlayerPos = []
	coordenadaDirPlayerPos = []
	coordenadaBaixoPlayerPos = []

	coordenadaEsqPlayerPos = [player_pos[0]-1, player_pos[1]]
	coordenadaCimaPlayerPos = [player_pos[0], player_pos[1]-1] 
	coordenadaDirPlayerPos = [player_pos[0]+1, player_pos[1]]
	coordenadaBaixoPlayerPos = [player_pos[0], player_pos[1]+1]

	#lista vai ser algo assim
	#lista = [(coordenada), funcaoF, movimento]

	if validaMovimento(visitados, coordenadaEsqPlayerPos, map) == True:
		#calculo custo f e guardo numa lista junto com o movimento

		lucro = calculaLucro(coordenadaEsqPlayerPos, resources)

		x = tuple(coordenadaEsqPlayerPos)	
		if map[x] == -1:
			F = -20
			possiveisMovimentos.insert(i, (coordenadaEsqPlayerPos,F, 4))
			i+=1
		else: 
			print("....Esq....")
			F = lucro - calcularGeH(map, coordenadaEsqPlayerPos, player_pos, destino)
			print("--------------------")
			possiveisMovimentos.insert(i, (coordenadaEsqPlayerPos, F, 4))
			i+=1
	if validaMovimento(visitados, coordenadaCimaPlayerPos, map) == True:
		#calculo custo f e guardo numa lista junto com o movimento

		lucro = calculaLucro(coordenadaCimaPlayerPos, resources)

		x = tuple(coordenadaCimaPlayerPos)
		if map[x] == -1:
			F = -20
			possiveisMovimentos.insert(i, (coordenadaCimaPlayerPos,F, 1))
			i+=1
		else:
			print("....Cima....")
			F = lucro - calcularGeH(map, coordenadaCimaPlayerPos, player_pos, destino)
			print("--------------------")
			possiveisMovimentos.insert(i, (coordenadaCimaPlayerPos, F, 1))
			i+=1
	if validaMovimento(visitados, coordenadaDirPlayerPos, map) == True:
		#calculo custo f e guardo numa lista junto com o movimento

		lucro = calculaLucro(coordenadaDirPlayerPos, resources)

		x = tuple(coordenadaDirPlayerPos)
		if map[x] == -1:
			F = -20
			possiveisMovimentos.insert(i, (coordenadaDirPlayerPos,F, 3))
			i+=1
		else:
			print("....Dir....")
			F = lucro - calcularGeH(map, coordenadaDirPlayerPos, player_pos, destino)
			print("--------------------")
			possiveisMovimentos.insert(i, (coordenadaDirPlayerPos, F, 3))
			i+=1
	if validaMovimento(visitados, coordenadaBaixoPlayerPos, map) == True:
		#calculo custo f e guardo numa lista junto com o movimento

		lucro = calculaLucro(coordenadaDirPlayerPos, resources)

		x = tuple(coordenadaBaixoPlayerPos)
		if map[x] == -1:
			F = -20
			possiveisMovimentos.insert(i, (coordenadaBaixoPlayerPos,F, 2))
			i+=1
		else:
			print("....Baixo....")
			F = lucro - calcularGeH(map, coordenadaBaixoPlayerPos, player_pos, destino)
			print("--------------------")
			possiveisMovimentos.insert(i, (coordenadaBaixoPlayerPos, F, 2))
			i+=1	
	print("=================================================================")	
	return possiveisMovimentos

#ordeno uma lista com possiveis movimentos, pelo campo de f
def ordenarPossiveisMovimentos(possiveisMovimentos):
	possiveisMovimentos.sort(key=lambda x: x[-2])	
	return possiveisMovimentos

#retorna o melhor movimento a se fazer cima,baixo,esq,dir, com o menor custo F e maior lucro
def aEstrela(map, player_pos, destino, visitados, resources):

	franja = []
	x = []
	franja = calcularCustoF(map, player_pos, destino, visitados, resources)
	x = ordenarPossiveisMovimentos(franja)
	if len(x) == 0:
		return 100
	else:
		visitados.append(x[-1][0])
		franjaAberta = x[-1][2]
		return franjaAberta

#Pega o caminho feito pelo agente e transforma em inverso, para que assim ele possa voltar para base
def transformaCaminhoFeitoEmInverso(caminhoFeito):
	caminhoInverso = []
	x = []
	for i in range(0, len(caminhoFeito)):
		if caminhoFeito[i] == 1:
			caminhoInverso.append(2)
		else:
			if caminhoFeito[i] == 2:
				caminhoInverso.append(1)
			else:
				if caminhoFeito[i] == 3:
					caminhoInverso.append(4)
				else:
					if caminhoFeito[i] == 4:
						caminhoInverso.append(3)
	for i in range(0, len(caminhoInverso)):
		x.append(caminhoInverso[-1])
		del caminhoInverso[-1]
	return x

#Há um caso em que o agente estava ficando perdido, entao criei essa funcao pra fazer ele voltar pra posicao anterior
def rotornaUltimoMov(caminhoFeito):
	if caminhoFeito[-1] == 1:
		return 2
	else: 
		if caminhoFeito[-1] == 2:
			return 1
		else:
			if caminhoFeito[-1] == 3:
				return 4
			else:
				if caminhoFeito[-1] == 4:
					return 3

def move(map,resources,enemies_pos, enemies_bases, player_pos, player_base, carrying, score, e_score):
	m = [MOVE_UP, MOVE_DOWN, MOVE_RIGHT, MOVE_LEFT]
	global turno
	turno += 1
	print ("Turno: ", turno)
	global destino
	global visitados
	global caminhoFeito
	global caminhoInverso
	global posAnterior
	global z
	global k
	global y
	global j
	global n
	global varAux
	
	#para o caso do agente ficar perdido e nao ter saida
	if player_pos != player_base and varAux == 100:
		n += 1
		if n < len(caminhoInverso):
			#print("valor do k: ", n)
			y = transformaCaminhoFeitoEmInverso(caminhoFeito)
			caminhoInverso.clear()
			for i in range(0, len(y)):
				caminhoInverso.append(y[i])
			return caminhoInverso[n]
	else:	
		if player_pos == player_base and varAux == 100:
			#tive que converter o destino pra lista pra poder limpar ele
			a = list(destino)
			a.clear()
			tuple(a)
			destino = a
			varAux = 0
			visitados.clear()
			caminhoFeito.clear()
			caminhoInverso.clear()
			posAnterior.clear()
			k = -1
	
	#se eu estiver pego algum recurso e estiver fora da base
	if len(posAnterior)!=0 and carrying == None:
		#print("Entrei aqui1")
		x = posAnterior[0]
		del posAnterior[0]
		k = -1
		return x

	#se eu estiver na base e o destino ainda nao foi escolhido
	if player_pos == player_base:
		if len(destino) == 0:
			#print("Entrei aqui")
			destino = escolheDestino(resources)
			n = -1

	#se eu estiver na base e nao estiver carregando nada
	if player_pos == player_base and carrying == None:
		j += 1
		#print("Entrei aqui3")
		mov = aEstrela(map,player_pos,destino, visitados, resources)
		#se eu estiver em um lugar sem saida, quer dizer que nao poderei fazer nenhum movimento, entao terei que voltar pra base
		if mov == 100:
			#print("entrei aqui 1")
			varAux = mov
			return rotornaUltimoMov(caminhoFeito)
		else:
			caminhoFeito.append(mov)
			if j == 0:	
				a = list(player_base)
				visitados.append(a)
			j+=1
			return mov

	#se eu estiver fora da base e estiver carregando alguma coisa, retorno pra base
	if player_pos != player_base and carrying != None:
		#print("Entrei aqui4")
		k += 1
		y = transformaCaminhoFeitoEmInverso(caminhoFeito)
		caminhoInverso.clear()
		for i in range(0, len(y)):
			caminhoInverso.append(y[i])
		#print("Caminho Feito: ", caminhoFeito)
		#print("Caminho inverso: ", caminhoInverso)
		posAnterior.clear()
		for i in range(0, len(caminhoFeito)):
			posAnterior.insert(i, caminhoFeito[i])
		return caminhoInverso[k]
		
	#se eu nao estiver na base e nao estar carregando alguma coisa
	if player_pos!= player_base and carrying == None:
		#print("Entrei aqui5")
		#print("Visitados: ", visitados)
		mov = aEstrela(map, player_pos, destino, visitados, resources)
		#se eu estiver em um lugar sem saida, quer dizer que nao poderei fazer nenhum movimento, entao terei que voltar pra base
		if mov == 100:
			#print("entrei aqui 2")
			varAux = mov
			return rotornaUltimoMov(caminhoFeito)
		else:	
			caminhoFeito.append(mov)
			return mov